# Anime Ascension Android — V11.8.0

Full Android WebView wrapper for the mobile game.

## Build locally
Requirements: JDK 17, Android SDK 36, Android Build Tools 35+, Gradle 8.13.

```bash
gradle :app:assembleDebug
```

Debug APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions
Push this folder as a repository. The included workflow builds debug/release APKs and a release AAB, then uploads them as workflow artifacts.

The release APK/AAB produced by the workflow is unsigned unless signing is configured. The debug APK is automatically debug-signed by the Android Gradle Plugin and is directly installable for testing.


## V11.8.0 combat animation update
All seven player fighters use new six-pose combat animation sheets for idle, movement, attacks, skills, recovery/hit feedback, and ultimates.
